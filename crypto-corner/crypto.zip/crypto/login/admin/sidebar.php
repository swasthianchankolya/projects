

  
<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="index.php" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
					


            			<li>
							<a href="#addempc" data-toggle="collapse" class="collapsed"><i class="lnr lnr-code"></i></i> <span>Employee</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="addempc" class="collapse ">
								<ul class="nav">
									<li><a href="addemp.php" class="">Add Employee</a></li>
									<li><a href="vemp.php" class="">Employee</a></li>
									
								</ul>
							</div>
						</li>



            			<li>
							<a href="#ass" data-toggle="collapse" class="collapsed"><i class="lnr lnr-chart-bars"></i></i> <span>Assign</span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="ass" class="collapse ">
								<ul class="nav">
									<li><a href="asscltoemp.php" class="">Client To Employee</a></li>
								</ul>
							</div>
						</li>


            			<li>
							<a href="#viewec" data-toggle="collapse" class="collapsed"><i class="lnr lnr-user"></i> <span>Client  </span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="viewec" class="collapse ">
								<ul class="nav">
									
									<li><a href="addcl.php" class="">Add Client</a></li>
									<li><a href="vcl.php" class="">Client</a></li>
								</ul>
							</div>
						</li>
          
						<li><a href="verifyaf.php" class=""><i class="fa fa-random"></i> <span>Verify Audited Files</span></a></li>
						<li><a href="filecat.php" class=""><i class="lnr lnr-dice"></i> <span>File Categories</span></a></li>
						<li><a href="payment.php" class=""><i class="fa fa-credit-card"></i> <span>Payment</span></a></li>
						<li>
							<a href="#msg" data-toggle="collapse" class="collapsed"><i class="lnr lnr-chart-bars"></i> <span>Messages  </span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="msg" class="collapse ">
								<ul class="nav">
									<li><a href="sendmessges.php" class="">Send Message</a></li>
									<li><a href="fromemessges.php" class="">From Employee</a></li>
									<li><a href="fromcmessges.php" class="">From Client</a></li>
								</ul>
							</div>
						</li>
						<li><a href="query.php" class=""><i class="lnr lnr-linearicons"></i> <span>Query</span></a></li>
						<li><a href="replay.php" class=""><i class="lnr lnr-chart-bars"></i> <span>Query Replies</span></a></li>
						<li><a href="../../Controller/logout.php" class=""><i class="fa fa-random"></i> <span>Logout</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->