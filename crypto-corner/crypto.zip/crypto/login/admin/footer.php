        <footer>
			<div class="container-fluid">
				<p class="copyright">&copy; 2021 <a href="#" target="_blank">Virtunetic</a>. All Rights Reserved.</p>
			</div>
		</footer>