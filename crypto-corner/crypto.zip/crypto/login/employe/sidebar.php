

  
<!-- LEFT SIDEBAR -->
		<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="index.php" class="active"><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="profile.php"><i class="lnr lnr-user"></i> <span>Profile</span></a></li>
			
            			<li><a href="viewcfiles.php" class=""><i class="fa fa-credit-card"></i> <span>View Files</span></a></li>
						<li><a href="vcl.php" class=""><i class="lnr lnr-chart-bars"></i> <span>View Clients</span></a></li>
						

						<li><a href="aud.php" class=""><i class="lnr lnr-dice"></i> <span>Audited Files</span></a></li>
						<li>
							<a href="#msg" data-toggle="collapse" class="collapsed"><i class="lnr lnr-chart-bars"></i> <span>Messages  </span> <i class="icon-submenu lnr lnr-chevron-left"></i></a>
							<div id="msg" class="collapse ">
								<ul class="nav">
									<li><a href="sendmessges.php" class="">Send Message</a></li>
									<li><a href="replayfa.php" class="">Replay From Admin</a></li>
								</ul>
							</div>
						</li>
					
						<li><a href="../../Controller/logout.php" class=""><i class="fa fa-random"></i> <span>Logout</span></a></li>
					</ul>
				</nav>
			</div>
		</div>
		<!-- END LEFT SIDEBAR -->