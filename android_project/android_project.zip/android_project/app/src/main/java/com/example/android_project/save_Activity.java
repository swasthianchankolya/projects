package com.example.android_project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.scottyab.aescrypt.AESCrypt;

import java.security.GeneralSecurityException;

public class save_Activity extends AppCompatActivity {
    EditText keyvalue,account,username,password;
    Button savedata,getdata,home;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);

        try {
          this.getSupportActionBar().hide();
        }
        catch (NullPointerException e)
        {

        }
        username=(EditText) findViewById(R.id.username);
        password=(EditText) findViewById(R.id.password);
        account=(EditText)findViewById(R.id.account);
        keyvalue=(EditText) findViewById(R.id.keyvalue);
        savedata=(Button) findViewById(R.id.btnsavedata);
        getdata=(Button) findViewById(R.id.btngetdata);
        home=(Button)findViewById(R.id.homebtn);
        DB=new DBHelper(this);

        savedata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user=username.getText().toString();
                String pass=password.getText().toString();
                String acc=account.getText().toString();
                String keyval=keyvalue.getText().toString();

                String key="password";
                String finalpass="";
                String finalkey="";
                try
                {
                    String newpass= AESCrypt.encrypt(key,pass);
                    finalpass=newpass;
                } catch (GeneralSecurityException e)
                {
                    e.printStackTrace();
                }
                try
                {
                    String newkey= AESCrypt.encrypt(key,keyval);
                    finalkey=newkey;
                } catch (GeneralSecurityException e)
                {
                    e.printStackTrace();
                }

                if(user.equals("")||pass.equals("")||acc.equals("")||keyval.equals(""))
                {
                    Toast.makeText(save_Activity.this, "please enter all the fields", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    if(user!="")
                    {
                        Boolean checkuser=DB.checkusername(user,acc);
                        if(checkuser==false)
                        {
                            Boolean insert=DB.insertData(user,finalpass,acc,finalkey);
                            if(insert==true)
                            {
                                Toast.makeText(save_Activity.this,"registered succesfully",Toast.LENGTH_SHORT).show();
                            }
                            else
                            {
                                Toast.makeText(save_Activity.this,"registration falied",Toast.LENGTH_SHORT).show();
                            }
                        }
                        else
                        {
                            Toast.makeText(save_Activity.this,"user already exist",Toast.LENGTH_SHORT).show();
                        }
                    }
                    else
                    {
                        Toast.makeText(save_Activity.this,"cant be blank",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        getdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),get_Activity.class);
                startActivity(intent);

            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);

            }
        });
    }
}