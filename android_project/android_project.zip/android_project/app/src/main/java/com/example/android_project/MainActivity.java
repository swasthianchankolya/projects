package com.example.android_project;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button savepass,getpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        savepass=(Button) findViewById(R.id.savepass);
        getpass=(Button) findViewById(R.id.getpass);
        try {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e)
        {

        }
       savepass.setOnClickListener(new View.OnClickListener()
       {
           @Override
           public void onClick(View view)
           {
               Intent intent=new Intent(getApplicationContext(),save_Activity.class);
               startActivity(intent);
           }
       });
        getpass.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Intent intent=new Intent(getApplicationContext(),get_Activity.class);
                startActivity(intent);
            }
        });
    }
}