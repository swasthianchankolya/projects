package com.example.android_project;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.scottyab.aescrypt.AESCrypt;

import java.security.GeneralSecurityException;

public class get_Activity extends AppCompatActivity {

    EditText keyvalue;
    DBHelper DB;
    Button btnget,home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get);
        try {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e)
        {

        }
        btnget=(Button) findViewById(R.id.btngetdata);
        keyvalue=findViewById(R.id.type);
        home=(Button)findViewById(R.id.gohome);
        // t=(TextView)findViewById(R.id.tview);
        DB=new DBHelper(this);

        btnget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String name="swasthik";
                String keyval=keyvalue.getText().toString();
                String keyv="password";
                String finalkey="";
                try
                {
                    String newkey= AESCrypt.encrypt(keyv,keyval);
                    finalkey=newkey;
                } catch (GeneralSecurityException e)
                {
                    e.printStackTrace();
                }
                Cursor res=DB.getdata_instagram(finalkey);
                if(res.getCount()==0)
                {
                    Toast.makeText(get_Activity.this,"no data",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                String key="password";
                while (res.moveToNext())
                {
                    String username=res.getString(0);
                    String password="";
                    try {
                        password= AESCrypt.decrypt(key,res.getString(1));
                    }
                    catch (GeneralSecurityException e)
                    {
                        e.printStackTrace();
                    }
                    String type=res.getString(2);
                    String keyvalue=res.getString(3);
                    buffer.append("username:" + username + "\n");
                    buffer.append("password:" + password + "\n");
                    buffer.append("account:" + type + "\n\n");
                   // buffer.append("key:" + keyvalue + "\n\n");
                }
                AlertDialog.Builder builder = new AlertDialog.Builder(get_Activity.this);
                builder.setCancelable(true);
                builder.setTitle("SAVED PASSWORDS");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
    }
}